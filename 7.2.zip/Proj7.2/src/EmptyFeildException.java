import java.util.*;
import java.lang.*;
import java.io.*;
public class EmptyFeildException extends Exception{
	String message;
	EmptyFeildException(String str)
	{
		message=str;
	
	}
	public String toString() {
		return("Exception Occured:"+message);
		
	}
}
class Codechef{
	public static void main(String[] args)throws java.lang.Exception 
	{
		Scanner sc=new Scanner(System.in);
		String name="",Address="";
		int rollno=0,age=0;
		try
		{
			name=sc.nextLine();
			if(name.equals(""))
			{
				throw new EmptyFeildException("Name cant't be empty");
			}
			Address=sc.nextLine();
			if(Address.equals(""))
			{
				throw new EmptyFeildException("Address can't be empty");
			}
			rollno=sc.nextInt();
			age=sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.out.println("Input Mismatch Exception occured, Enter Integer value for rollno and age");
		}
		catch(EmptyFeildException e)
		{
			System.out.println(e);
		}
	}

}