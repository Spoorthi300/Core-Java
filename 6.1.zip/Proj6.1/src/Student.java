import java.util.*;
import java.util.ArrayList;
public class Student {
	public static void main(String[] args) {
		
		ArrayList<String>list =new ArrayList<>();
		
		list.add("Abhi");
		list.add("Bhumika");
		list.add("Chethan");
		list.add("Darshana");
		list.add("Gagan");
		
		if(list.indexOf("Abhi")>=0)
		System.out.println("Abhi exists in the arraylist");
		
		else
			System.out.println("Abhi doesnot exits in the arraylist");
		
		if(list.indexOf("Spoo")>=0)
			System.out.println("Spoo exists in the arraylist");
		else
			System.out.println("Spoo doesnot exist in the arraylist");
			
		
	}

}
