import java.util.Arrays;

public class Proj6 {
	public static void main(String[] args) {
		
	
	String number = "23+45-(343/12)";
	number = replacing(number);
	String[] split = number.split(" ");
	}
	
	public static String replacing1(String s) {
		   String[] chars = {"+", "-", "/", "(",")"};

		   for (String character : chars) {
		      if (s.contains(character)) {
		         s = s.replace(character, " " + character + " ");//not exactly elegant, but it works
		      }
		   }
		   return s;
		
	
    String[] split;
	split[0]="23";
    split[1]="+"; 
    split[2]="45";
    split[3]="-";
    split[4]="(";
    split[5]="343";
    split[6]="/";
    split[7]="12";
    split[8]=")";
    System.out.println( split[0]);
    System.out.println( split[1]);
    System.out.println( split[2]);
    System.out.println( split[3]);
    System.out.println( split[4]);
    System.out.println( split[5]);
    System.out.println( split[6]);
    System.out.println( split[7]);
    System.out.println( split[8]);
    
}

	private static String replacing(String number) {
		// TODO Auto-generated method stub
		return null;
	}
}