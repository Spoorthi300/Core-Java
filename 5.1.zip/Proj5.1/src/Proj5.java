
public class Proj5 {
public static void main(String[] args) 
  {
	String str ="JAVA is Simple";
	StringBuilder str1=new StringBuilder();
	str1.append(str);
	str1.reverse();
	
	System.out.println(str.toUpperCase());
	System.out.println(str.toLowerCase());
	System.out.print(str.charAt(0));
	System.out.println(str.split(str));
	System.out.println(str.length());
	System.out.println(str1);
	
  }

private static char split() {

	return 0;
}
}
