package testrectangle;

public class Rectangle {
	double length,breadth;
	Rectangle()
	{
		length=1;
		breadth=1;
	}
	Rectangle(double length,double breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	double getArea()
	{
		return length*breadth;
		
	}
	double getPerimeter()
	{
		return(2*(length+breadth));
	}
	int getNumberofvertices() 
	{
		return 4;		
	}
}

		
		




