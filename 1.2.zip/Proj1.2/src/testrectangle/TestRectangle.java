package testrectangle;

public class TestRectangle {

		
		public static void main(String[] args) {

				
				Rectangle rect1=new Rectangle();
				Rectangle rect2=new Rectangle(15.0,8.0);
				Rectangle rect3=new Rectangle(4.0,2.0);
				Rectangle rect4=new Rectangle(18.3,28.9);
				Rectangle rect5=new Rectangle(17.9,9.0);
				
				System.out.println("Area of first object= "+rect1.getArea());
				System.out.println("Perimeter of first object= "+rect1.getPerimeter());
				System.out.println("Numberofvertices of first object= "+rect1 );
				
				System.out.println("Area of second object= "+rect2.getArea());
				System.out.println("Perimeter of second object= "+rect2.getPerimeter());
				System.out.println("Numberofvertices of second object= "+rect2 );
				
				System.out.println("Area of third object= "+rect3.getArea());
				System.out.println("Perimeter of third object= "+rect3.getPerimeter());
				System.out.println("Numberofvertices of third object= "+rect3 );
				
				System.out.println("Area of fourth object= "+rect4.getArea());
				System.out.println("Perimeter of fourth object= "+rect4.getPerimeter());
				System.out.println("Numberofvertices of fourth object= "+rect4 );
				
				System.out.println("Area of fifth object= "+rect5.getArea());
				System.out.println("Perimeter of fifth object= "+rect5.getPerimeter());
				System.out.println("Numberofvertices of fifth object= "+rect5 );
				
				
			}
		}



