import java.util.Scanner;

public class Fibonacci {
  public static void main(String[] args) {
	        int n=13, a, b ;
	        Scanner input =new Scanner(System.in);
	        System.out.println("Enter the  value of a: ");
	        a=input.nextInt();
	        Scanner input1 =new Scanner(System.in);
	        System.out.println("Enter the value of b: ");
	        b=input1.nextInt();
	        System.out.println("Fibonacci series till "+n+"terms:");
	        
	        for(int i=1;i<=n;++i)
	        {
	        	System.out.println(a+", ");
	        	
	        	int c=a+b;
	        	    a=b;
	        	    b=c;
	        }
      }
}
