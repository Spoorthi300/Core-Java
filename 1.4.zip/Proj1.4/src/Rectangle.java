
public class Rectangle {
	 private float length,width;
	{
		length=1;
		width=1;
	}
	 public float getArea()
	    {
	    	float area=this.length*this.width;
	    	return area;
	    }
	    public float getPerimeter()
	    {
	    	float perimeter= 2*(this.length+this.width);
	    	return perimeter;
	    }
	
	      public void setValues(float length,float width)
	      {
	    	  if(length>0 &&  length<20)
	    		  this.length = length;
	    	  if(width>0 && width<20)
	    		  this.width = width;
	      }
	
	
	public float getLength() {
		
		return length;
	}
	public void setLength(float length) {
		
		this.length = length;
	}
	public float getWidth() {
		return width;
	}
	public void setWidth(float width ) {
		this.width =width;
		
	}
   
}

	
	