import java.util.HashSet;

public class ProductClass{
 public static void main(String args[]){
    HashSet<String> set1 = new HashSet<String>();
    HashSet<String> productid = null;
	set1=productid;
    set1.add("P001");
    set1.add("P002");
    set1.add("P003");
    set1.add("P004");
    
    
    HashSet<String> set2 = new HashSet<String>();
    HashSet<String> productname = null;
	set2=productname;
    set2.add("Maruti 800");
    set2.add("Maruti Zen");
    set2.add("Maruti Dezire");
    set2.add("Maruti Alto");
    
   
    System.out.println("set1-set2");
  }
}
