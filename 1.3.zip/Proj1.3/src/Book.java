public class Book {
	
	
	private String _title;
    private double _price;
   
    public Book(String title,double price)
    {
    	_title = title;
    	_price = price;
    }
     public String getTitle() 
     {
    	 return _title;
     }
	public String get_title() {
		return _title;
	}
	public void set_title(String _title) {
		this._title = _title;
	}
	public double get_price() {
		return _price;
	}
	public void set_price(double _price) {
		this._price = _price;
	}
     public String toString() {
    	 return "Book Title: "+_title + "\n" + "Price: " + _price + "\n";
     }

}
