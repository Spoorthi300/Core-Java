
public class createBooks {
public static void main(String[] args) {
	
	Book book1,book2;
	book1 = new Book("Java Programming",350.50);
	book2 = new Book("Let Us C",200.00);
	
	System.out.println(book1);
	System.out.println(book2);
	
}
}
